# matrix trace
matrixTrace <- function(squareMatrix){
	return(sum(diag(squareMatrix)))
}
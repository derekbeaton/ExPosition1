PDQ <-
function(datain,k=0){
	return(basePDQ(datain,k=k))	
}

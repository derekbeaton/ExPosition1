DistatisR.1.1.0
DistatisR an R-package implementing distatis et allies 
methods---3-ways metric multidimentional scaling.

1) Be sure to have R installed

2) Create a directory (folder) on your computer. Make sure it's easy to access and remember (e.g., /Users/derekbeaton/Desktop/SWPA/ANOVA).

3) Download "0_DOWNLOAD_ME-ANOVA.zip" to the directory you just created.

4) Unzip (extract) the .zip file in the directory you created. 

5) Be sure that in R you are familiar with changing directories (i.e., setwd() ), so that you can point R to the directory you created.
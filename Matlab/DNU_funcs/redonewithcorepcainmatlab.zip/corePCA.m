function [fi, di, ri, ci, fj, dj, rj, cj, t, eigsss,M,W,p, q, Dv, Dd, ng] = corePCA(DATA)

% M and W aren't being used for now
if ~exist('M'), M = ones(1, size(DATA,1)); end
if ~exist('W'), W = ones(1, size(DATA,2)); end

% scaling data

[DATA center scale]= zscore(DATA); % center and scale are not returned
[I,J] = size(DATA);
% to the kitchin
[p, q, Dv, Dd, ng, tau] = genPDQ(DATA, M, W,I,J);

% Note : the following code adapted from MuSuBADA_V4
D=diag(Dd); l=D.^2;nf = length(l);


fi=p * Dd;
di=sum(fi.^2,2);
ri=repmat((1./di),1,nf ) .* ( fi.^2);
ci=(fi.^2)./repmat(l',I,1);
fj=q * Dd;
dj=sum(fj.^2,2);
rj=repmat((1./dj),1,nf ).*( fj.^2);
cj=(fj.^2)./repmat(l',J,1);
t = tau;
eigsss = Dv.^2 ;


end